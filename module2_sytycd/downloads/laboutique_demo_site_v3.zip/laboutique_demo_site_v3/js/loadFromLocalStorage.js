loadFromLocalStorage();

function loadFromLocalStorage() {
    if (localStorage.getItem("loadconfigfromjsonstatus") === "success") {
                console.log(">>>>> Started Loading Brand Profile from Local Storage!");
                //******************************************
                //Displaying Brand Profile values on website
                //******************************************
                $("#brandlogo").attr("src", localStorage.getItem('brandlogo'));
                $("#faviconlink").attr("href", localStorage.getItem('faviconlink'));
                document.getElementById("footerCredits").innerHTML = "&copy; 2019 Wouter Van Geluwe - v3 - Module 2 SYTYCD &middot; All Rights Reserved. <button onclick='loadJSON()'>Reload</button>";
                if(localStorage.getItem('demosetuptype') === "quickandnotsodirty"){
                    $("#carticon").attr("style", "display:none;");
                }else if(localStorage.getItem('demosetuptype') === "fullecommerceready"){
                    $("#carticon").attr("style", "display:block;");
                }

                //******************************************
                //Displaying Brand Profile values on website
                //******************************************
                if(localStorage.getItem('page0active') == "true"){
                    document.getElementById("page0").innerHTML = "<a href='" + localStorage.getItem('page0url') + "'>" + localStorage.getItem('page0title') + "</a>";
                }
                if(localStorage.getItem('page1active') == "true"){
                    document.getElementById("page1").innerHTML = "<a href='" + localStorage.getItem('page1url') + "'>" + localStorage.getItem('page1title') + "</a>";
                }
                if(localStorage.getItem('page2active') == "true"){
                    document.getElementById("page2").innerHTML = "<a href='" + localStorage.getItem('page2url') + "'>" + localStorage.getItem('page2title') + "</a>";
                }
                if(localStorage.getItem('page3active') == "true"){
                    document.getElementById("page3").innerHTML = "<a href='" + localStorage.getItem('page3url') + "'>" + localStorage.getItem('page3title') + "</a>";
                }
                if(localStorage.getItem('page4active') == "true"){
                    document.getElementById("page4").innerHTML = "<a href='" + localStorage.getItem('page4url') + "'>" + localStorage.getItem('page4title') + "</a>";
                }
                if(localStorage.getItem('page5active') == "true"){
                    document.getElementById("page5").innerHTML = "<a href='" + localStorage.getItem('page5url') + "'>" + localStorage.getItem('page5title') + "</a>";
                }
                if(localStorage.getItem('page6active') == "true"){
                    document.getElementById("page6").innerHTML = "<a href='" + localStorage.getItem('page6url') + "'>" + localStorage.getItem('page6title') + "</a>";
                }
                if(localStorage.getItem('page7active') == "true"){
                    document.getElementById("page7").innerHTML = "<a href='" + localStorage.getItem('page7url') + "'>" + localStorage.getItem('page7title') + "</a>";
                }
                if(localStorage.getItem('page8active') == "true"){
                    document.getElementById("page8").innerHTML = "<a href='" + localStorage.getItem('page8url') + "'>" + localStorage.getItem('page8title') + "</a>";
                }
                if(localStorage.getItem('page9active') == "true"){
                    document.getElementById("page9").innerHTML = "<a href='" + localStorage.getItem('page9url') + "'>" + localStorage.getItem('page9title') + "</a>";
                }
                if(localStorage.getItem('pageDMPactive') == "true"){
                    document.getElementById("pageDMP").innerHTML = "<a href='" + localStorage.getItem('pageDMPurl') + "'>" + localStorage.getItem('pageDMPtitle') + "</a>";
                }


                //*******************************************
                //Displaying Brand Profile values on homepage
                //*******************************************
                if(digitalData.page.home === true){
                    console.log(">>>>> Homepage detected.")

                    window.document.title = localStorage.getItem('brandname') + " Home";
                    $("#brandhero").attr("src", localStorage.getItem('brandhero'));
                    $("#brandcalltoaction").attr("href", localStorage.getItem('brandcalltoactionurl'));
                    document.getElementById("brandcalltoaction").innerHTML = "<h3>" + localStorage.getItem('brandcalltoaction') + "</h3>"

                    //Product 1
                    if(localStorage.getItem('product1active') == "true"){
                        $("#p1-url").attr("href", localStorage.getItem('product1url'));
                        $("#p1-url").attr("title", localStorage.getItem('product1name'));
                        $("#p1-img1").attr("src", localStorage.getItem('product1image1'));
                        $("#p1-img2").attr("src", localStorage.getItem('product1image2'));
                        document.getElementById("p1-title").innerHTML = localStorage.getItem('product1name');
                        document.getElementById("p1-price").innerHTML = localStorage.getItem('product1price');
                        $("#p1-url").attr("style", "display:block;");
                        $("#productList1").attr("style", "height:530px;");
                    }

                    //Product 2
                    if(localStorage.getItem('product2active') == "true"){
                        $("#p2-url").attr("href", localStorage.getItem('product2url'));
                        $("#p2-url").attr("title", localStorage.getItem('product2name'));
                        $("#p2-img1").attr("src", localStorage.getItem('product2image1'));
                        $("#p2-img2").attr("src", localStorage.getItem('product2image2'));
                        document.getElementById("p2-title").innerHTML = localStorage.getItem('product2name');
                        document.getElementById("p2-price").innerHTML = localStorage.getItem('product2price');
                        $("#p2-url").attr("style", "display:block;");
                        $("#productList1").attr("style", "height:530px;");
                    }

                    //Product 3
                    if(localStorage.getItem('product3active') == "true"){
                        $("#p3-url").attr("href", localStorage.getItem('product3url'));
                        $("#p3-url").attr("title", localStorage.getItem('product3name'));
                        $("#p3-img1").attr("src", localStorage.getItem('product3image1'));
                        $("#p3-img2").attr("src", localStorage.getItem('product3image2'));
                        document.getElementById("p3-title").innerHTML = localStorage.getItem('product3name');
                        document.getElementById("p3-price").innerHTML = localStorage.getItem('product3price');
                        $("#p3-url").attr("style", "display:block;");
                        $("#productList1").attr("style", "height:530px;");
                    }

                    //Product 4
                    if(localStorage.getItem('product4active') == "true"){
                        $("#p4-url").attr("href", localStorage.getItem('product4url'));
                        $("#p4-url").attr("title", localStorage.getItem('product4name'));
                        $("#p4-img1").attr("src", localStorage.getItem('product4image1'));
                        $("#p4-img2").attr("src", localStorage.getItem('product4image2'));
                        document.getElementById("p4-title").innerHTML = localStorage.getItem('product4name');
                        document.getElementById("p4-price").innerHTML = localStorage.getItem('product4price');
                        $("#p4-url").attr("style", "display:block;");
                        $("#productList1").attr("style", "height:530px;");
                    }

                    //Product 5
                    if(localStorage.getItem('product5active') == "true"){
                        $("#p5-url").attr("href", localStorage.getItem('product5url'));
                        $("#p5-url").attr("title", localStorage.getItem('product5name'));
                        $("#p5-img1").attr("src", localStorage.getItem('product5image1'));
                        $("#p5-img2").attr("src", localStorage.getItem('product5image2'));
                        document.getElementById("p5-title").innerHTML = localStorage.getItem('product5name');
                        document.getElementById("p5-price").innerHTML = localStorage.getItem('product5price');
                        $("#p5-url").attr("style", "display:block;");
                        $("#productList2").attr("style", "height:530px;");
                    }

                    //Product 6
                    if(localStorage.getItem('product6active') == "true"){
                        $("#p6-url").attr("href", localStorage.getItem('product6url'));
                        $("#p6-url").attr("title", localStorage.getItem('product6name'));
                        $("#p6-img1").attr("src", localStorage.getItem('product6image1'));
                        $("#p6-img2").attr("src", localStorage.getItem('product6image2'));
                        document.getElementById("p6-title").innerHTML = localStorage.getItem('product6name');
                        document.getElementById("p6-price").innerHTML = localStorage.getItem('product6price');
                        $("#p6-url").attr("style", "display:block;");
                        $("#productList2").attr("style", "height:530px;");
                    }

                    //Product 7
                    if(localStorage.getItem('product7active') == "true"){
                        $("#p7-url").attr("href", localStorage.getItem('product7url'));
                        $("#p7-url").attr("title", localStorage.getItem('product7name'));
                        $("#p7-img1").attr("src", localStorage.getItem('product7image1'));
                        $("#p7-img2").attr("src", localStorage.getItem('product7image2'));
                        document.getElementById("p7-title").innerHTML = localStorage.getItem('product7name');
                        document.getElementById("p7-price").innerHTML = localStorage.getItem('product7price');
                        $("#p7-url").attr("style", "display:block;");
                        $("#productList2").attr("style", "height:530px;");
                    }

                    //Product 8
                    if(localStorage.getItem('product8active') == "true"){
                        $("#p8-url").attr("href", localStorage.getItem('product8url'));
                        $("#p8-url").attr("title", localStorage.getItem('product8name'));
                        $("#p8-img1").attr("src", localStorage.getItem('product8image1'));
                        $("#p8-img2").attr("src", localStorage.getItem('product8image2'));
                        document.getElementById("p8-title").innerHTML = localStorage.getItem('product8name');
                        document.getElementById("p8-price").innerHTML = localStorage.getItem('product8price');
                        $("#p8-url").attr("style", "display:block;");
                        $("#productList2").attr("style", "height:530px;");
                    }
                }
                //************************************************
                //Displaying Product values on Product Detail Page
                //************************************************
                if(digitalData.page.productdtl === true){
                    console.log(">>>>> Product Detail page detected.")
                    switch (digitalData.page.number) {
                      case 1:
                        document.title = localStorage.getItem('product1name');
                        digitalData.product.imageUrl = localStorage.getItem('product1eeimgurl');
                        digitalData.product.price = localStorage.getItem('product1price');
                        digitalData.product.category = localStorage.getItem('product1category');
                        digitalData.product.name = localStorage.getItem('product1name');
                        digitalData.product.interaction = "productView";
                        document.getElementById("productname").innerHTML = localStorage.getItem('product1name');
                        document.getElementById("productprice").innerHTML = localStorage.getItem('product1price');
                        document.getElementById("productdescription").innerHTML = localStorage.getItem('product1description');
                        $("#primaryimg1").attr("src", localStorage.getItem('product1image1'));
                        $("#primaryimg1").attr("data-zoom-image", localStorage.getItem('product1image1'));
                        $("#galleryimg1").attr("data-image", localStorage.getItem('product1image1'));
                        $("#galleryimg1").attr("data-zoom-image", localStorage.getItem('product1image1'));
                        $("#galleryrealimg1").attr("src", localStorage.getItem('product1image1'));
                        $("#galleryimg2").attr("data-image", localStorage.getItem('product1image2'));
                        $("#galleryimg2").attr("data-zoom-image", localStorage.getItem('product1image2'));
                        $("#galleryrealimg2").attr("src", localStorage.getItem('product1image2'));

                        break;
                      case 2:
                        document.title = localStorage.getItem('product2name');
                        digitalData.product.imageUrl = localStorage.getItem('product2eeimgurl');
                        digitalData.product.price = localStorage.getItem('product2price');
                        digitalData.product.category = localStorage.getItem('product2category');
                        digitalData.product.name = localStorage.getItem('product2name');
                        digitalData.product.interaction = "productView";
                        document.getElementById("productname").innerHTML = localStorage.getItem('product2name');
                        document.getElementById("productprice").innerHTML = localStorage.getItem('product2price');
                        document.getElementById("productdescription").innerHTML = localStorage.getItem('product2description');
                        $("#primaryimg1").attr("src", localStorage.getItem('product2image1'));
                        $("#primaryimg1").attr("data-zoom-image", localStorage.getItem('product2image1'));
                        $("#galleryimg1").attr("data-image", localStorage.getItem('product2image1'));
                        $("#galleryimg1").attr("data-zoom-image", localStorage.getItem('product2image1'));
                        $("#galleryrealimg1").attr("src", localStorage.getItem('product2image1'));
                        $("#galleryimg2").attr("data-image", localStorage.getItem('product2image2'));
                        $("#galleryimg2").attr("data-zoom-image", localStorage.getItem('product2image2'));
                        $("#galleryrealimg2").attr("src", localStorage.getItem('product2image2'));
                        
                        break;
                      case 3:
                        document.title = localStorage.getItem('product3name');
                        digitalData.product.imageUrl = localStorage.getItem('product3eeimgurl');
                        digitalData.product.price = localStorage.getItem('product3price');
                        digitalData.product.category = localStorage.getItem('product3category');
                        digitalData.product.name = localStorage.getItem('product3name');
                        digitalData.product.interaction = "productView";
                        document.getElementById("productname").innerHTML = localStorage.getItem('product3name');
                        document.getElementById("productprice").innerHTML = localStorage.getItem('product3price');
                        document.getElementById("productdescription").innerHTML = localStorage.getItem('product3description');
                        $("#primaryimg1").attr("src", localStorage.getItem('product3image1'));
                        $("#primaryimg1").attr("data-zoom-image", localStorage.getItem('product3image1'));
                        $("#galleryimg1").attr("data-image", localStorage.getItem('product3image1'));
                        $("#galleryimg1").attr("data-zoom-image", localStorage.getItem('product3image1'));
                        $("#galleryrealimg1").attr("src", localStorage.getItem('product3image1'));
                        $("#galleryimg2").attr("data-image", localStorage.getItem('product3image2'));
                        $("#galleryimg2").attr("data-zoom-image", localStorage.getItem('product3image2'));
                        $("#galleryrealimg2").attr("src", localStorage.getItem('product3image2'));
                        
                        break;
                      case 4:
                        document.title = localStorage.getItem('product4name');
                        digitalData.product.imageUrl = localStorage.getItem('product4eeimgurl');
                        digitalData.product.price = localStorage.getItem('product4price');
                        digitalData.product.category = localStorage.getItem('product4category');
                        digitalData.product.name = localStorage.getItem('product4name');
                        digitalData.product.interaction = "productView";
                        document.getElementById("productname").innerHTML = localStorage.getItem('product4name');
                        document.getElementById("productprice").innerHTML = localStorage.getItem('product4price');
                        document.getElementById("productdescription").innerHTML = localStorage.getItem('product4description');
                        $("#primaryimg1").attr("src", localStorage.getItem('product4image1'));
                        $("#primaryimg1").attr("data-zoom-image", localStorage.getItem('product4image1'));
                        $("#galleryimg1").attr("data-image", localStorage.getItem('product4image1'));
                        $("#galleryimg1").attr("data-zoom-image", localStorage.getItem('product4image1'));
                        $("#galleryrealimg1").attr("src", localStorage.getItem('product4image1'));
                        $("#galleryimg2").attr("data-image", localStorage.getItem('product4image2'));
                        $("#galleryimg2").attr("data-zoom-image", localStorage.getItem('product4image2'));
                        $("#galleryrealimg2").attr("src", localStorage.getItem('product4image2'));
                        
                        break;
                      case 5:
                        document.title = localStorage.getItem('product5name');
                        digitalData.product.imageUrl = localStorage.getItem('product5eeimgurl');
                        digitalData.product.price = localStorage.getItem('product5price');
                        digitalData.product.category = localStorage.getItem('product5category');
                        digitalData.product.name = localStorage.getItem('product5name');
                        digitalData.product.interaction = "productView";
                        document.getElementById("productname").innerHTML = localStorage.getItem('product5name');
                        document.getElementById("productprice").innerHTML = localStorage.getItem('product5price');
                        document.getElementById("productdescription").innerHTML = localStorage.getItem('product5description');
                        $("#primaryimg1").attr("src", localStorage.getItem('product5image1'));
                        $("#primaryimg1").attr("data-zoom-image", localStorage.getItem('product5image1'));
                        $("#galleryimg1").attr("data-image", localStorage.getItem('product5image1'));
                        $("#galleryimg1").attr("data-zoom-image", localStorage.getItem('product5image1'));
                        $("#galleryrealimg1").attr("src", localStorage.getItem('product5image1'));
                        $("#galleryimg2").attr("data-image", localStorage.getItem('product5image2'));
                        $("#galleryimg2").attr("data-zoom-image", localStorage.getItem('product5image2'));
                        $("#galleryrealimg2").attr("src", localStorage.getItem('product5image2'));
                        
                        break;
                      case 6:
                        document.title = localStorage.getItem('product6name');
                        digitalData.product.imageUrl = localStorage.getItem('product6eeimgurl');
                        digitalData.product.price = localStorage.getItem('product6price');
                        digitalData.product.category = localStorage.getItem('product6category');
                        digitalData.product.name = localStorage.getItem('product6name');
                        digitalData.product.interaction = "productView";
                        document.getElementById("productname").innerHTML = localStorage.getItem('product6name');
                        document.getElementById("productprice").innerHTML = localStorage.getItem('product6price');
                        document.getElementById("productdescription").innerHTML = localStorage.getItem('product6description');
                        $("#primaryimg1").attr("src", localStorage.getItem('product6image1'));
                        $("#primaryimg1").attr("data-zoom-image", localStorage.getItem('product6image1'));
                        $("#galleryimg1").attr("data-image", localStorage.getItem('product6image1'));
                        $("#galleryimg1").attr("data-zoom-image", localStorage.getItem('product6image1'));
                        $("#galleryrealimg1").attr("src", localStorage.getItem('product6image1'));
                        $("#galleryimg2").attr("data-image", localStorage.getItem('product6image2'));
                        $("#galleryimg2").attr("data-zoom-image", localStorage.getItem('product6image2'));
                        $("#galleryrealimg2").attr("src", localStorage.getItem('product6image2'));
                        
                        break;
                      case 7:
                        document.title = localStorage.getItem('product7name');
                        digitalData.product.imageUrl = localStorage.getItem('product7eeimgurl');
                        digitalData.product.price = localStorage.getItem('product7price');
                        digitalData.product.category = localStorage.getItem('product7category');
                        digitalData.product.name = localStorage.getItem('product7name');
                        digitalData.product.interaction = "productView";
                        document.getElementById("productname").innerHTML = localStorage.getItem('product7name');
                        document.getElementById("productprice").innerHTML = localStorage.getItem('product7price');
                        document.getElementById("productdescription").innerHTML = localStorage.getItem('product7description');
                        $("#primaryimg1").attr("src", localStorage.getItem('product7image1'));
                        $("#primaryimg1").attr("data-zoom-image", localStorage.getItem('product7image1'));
                        $("#galleryimg1").attr("data-image", localStorage.getItem('product7image1'));
                        $("#galleryimg1").attr("data-zoom-image", localStorage.getItem('product7image1'));
                        $("#galleryrealimg1").attr("src", localStorage.getItem('product7image1'));
                        $("#galleryimg2").attr("data-image", localStorage.getItem('product7image2'));
                        $("#galleryimg2").attr("data-zoom-image", localStorage.getItem('product7image2'));
                        $("#galleryrealimg2").attr("src", localStorage.getItem('product7image2'));
                        
                        break;
                      case 8:
                        document.title = localStorage.getItem('product8name');
                        digitalData.product.imageUrl = localStorage.getItem('product8eeimgurl');
                        digitalData.product.price = localStorage.getItem('product8price');
                        digitalData.product.category = localStorage.getItem('product8category');
                        digitalData.product.name = localStorage.getItem('product8name');
                        digitalData.product.interaction = "productView";
                        document.getElementById("productname").innerHTML = localStorage.getItem('product8name');
                        document.getElementById("productprice").innerHTML = localStorage.getItem('product8price');
                        document.getElementById("productdescription").innerHTML = localStorage.getItem('product8description');
                        $("#primaryimg1").attr("src", localStorage.getItem('product8image1'));
                        $("#primaryimg1").attr("data-zoom-image", localStorage.getItem('product8image1'));
                        $("#galleryimg1").attr("data-image", localStorage.getItem('product8image1'));
                        $("#galleryimg1").attr("data-zoom-image", localStorage.getItem('product8image1'));
                        $("#galleryrealimg1").attr("src", localStorage.getItem('product8image1'));
                        $("#galleryimg2").attr("data-image", localStorage.getItem('product8image2'));
                        $("#galleryimg2").attr("data-zoom-image", localStorage.getItem('product8image2'));
                        $("#galleryrealimg2").attr("src", localStorage.getItem('product8image2'));
                        
                        break;
                    }
                }

                //************************************************
                //Displaying Custom Page Info on Custom Pages
                //************************************************
                if(digitalData.page.custompage === true){
                    console.log(">>>>> Custom page detected.")
                    switch (digitalData.page.custompagenumber) {
                      case 1:
                        document.title = localStorage.getItem('page1title');
                        digitalData.product.imageUrl = localStorage.getItem('page1heroimage');
                        digitalData.product.price = "EUR 0.00";
                        digitalData.product.category = "Custom";
                        digitalData.product.interaction = "productView";
                        digitalData.product.name = localStorage.getItem('page1title');
                        digitalData.page.pageName = localStorage.getItem('page1title');
                        $("#custompageimage").attr("src", localStorage.getItem('page1heroimage'));

                        break;
                      case 2:
                        document.title = localStorage.getItem('page2title');
                        digitalData.product.imageUrl = localStorage.getItem('page2heroimage');
                        digitalData.product.price = "EUR 0.00";
                        digitalData.product.category = "Custom";
                        digitalData.product.interaction = "productView";
                        digitalData.page.pageName = localStorage.getItem('page2title');
                        digitalData.product.name = localStorage.getItem('page2title');
                        $("#custompageimage").attr("src", localStorage.getItem('page2heroimage'));
                        
                        break;
                      case 3:
                        document.title = localStorage.getItem('page3title');
                        digitalData.product.imageUrl = localStorage.getItem('page3heroimage');
                        digitalData.product.price = "EUR 0.00";
                        digitalData.product.category = "Custom";
                        digitalData.product.interaction = "productView";
                        digitalData.page.pageName = localStorage.getItem('page3title');
                        digitalData.product.name = localStorage.getItem('page3title');
                        $("#custompageimage").attr("src", localStorage.getItem('page3heroimage'));
                        
                        break;
                      case 4:
                        document.title = localStorage.getItem('page4title');
                        digitalData.product.imageUrl = localStorage.getItem('page4heroimage');
                        digitalData.product.price = "EUR 0.00";
                        digitalData.product.category = "Custom";
                        digitalData.product.interaction = "productView";
                        digitalData.page.pageName = localStorage.getItem('page4title');
                        digitalData.product.name = localStorage.getItem('page4title');
                        $("#custompageimage").attr("src", localStorage.getItem('page4heroimage'));
                        
                        break;
                      case 5:
                        document.title = localStorage.getItem('page5title');
                        digitalData.product.imageUrl = localStorage.getItem('page5heroimage');
                        digitalData.product.price = "EUR 0.00";
                        digitalData.product.category = "Custom";
                        digitalData.product.interaction = "productView";
                        digitalData.page.pageName = localStorage.getItem('page5title');
                        digitalData.product.name = localStorage.getItem('page5title');
                        $("#custompageimage").attr("src", localStorage.getItem('page5heroimage'));
                        
                        break;
                    }
                }

                //*******************************************
                //Displaying Register Page Custom Attributes 
                //*******************************************
                if(digitalData.page.registerpage === true){
                    console.log(">>>>> Registration page detected.");
                    if(localStorage.getItem('useShoeSize') === "true"){
                        $("#shoeSizeAttribute").attr("style", "display:block;");
                    }
                    if(localStorage.getItem('useShirtSize') === "true"){
                        $("#shirtSizeAttribute").attr("style", "display:block;");
                    }
                    if(localStorage.getItem('usePreferredColor') === "true"){
                        $("#preferredColorAttribute").attr("style", "display:block;");
                    }
                }

                //*******************************************
                //Displaying Media Page values on homepage
                //*******************************************
                if(digitalData.page.mediapage === true){
                    console.log(">>>>> Mediapage detected.");
                    document.title = localStorage.getItem('pageDMPtitle');
                    $("#newssite").attr("src", localStorage.getItem('pageDMPiframe'));
                    $("#displayad").attr("src", localStorage.getItem('displayad1imgurl'));
                }

                //*****************************************************************************************
                //Pre-populating Brand Profile values on admin page from Local Storage for editing/updating
                //*****************************************************************************************
                if(digitalData.page.adminpage === true){
                    console.log(">>>>> Adminpage detected.");
                    $("#brandName").attr("value", localStorage.getItem('brandname'));
                    $("#brandLogo").attr("value", localStorage.getItem('brandlogo'));
                    $("#brandFavIcon").attr("value", localStorage.getItem('faviconlink'));
                    $("#brandHeroImage").attr("value", localStorage.getItem('brandhero'));
                    $("#brandcalltoaction").attr("value", localStorage.getItem('brandcalltoaction'));
                    $("#brandcalltoactionurl").attr("value", localStorage.getItem('brandcalltoactionurl'));

                    if(localStorage.getItem('page1active') === "true"){
                        $("#page1Active").prop('checked', true);
                        $("#page1Title").attr("value", localStorage.getItem('page1title'));
                    }
                    if(localStorage.getItem('page2active') === "true"){
                        $("#page2Active").prop('checked', true);
                        $("#page2Title").attr("value", localStorage.getItem('page2title'));
                    }
                    if(localStorage.getItem('page3active') === "true"){
                        $("#page3Active").prop('checked', true);
                        $("#page3Title").attr("value", localStorage.getItem('page3title'));
                    }
                    if(localStorage.getItem('page4active') === "true"){
                        $("#page4Active").prop('checked', true);
                        $("#page4Title").attr("value", localStorage.getItem('page4title'));
                    }
                    if(localStorage.getItem('page5active') === "true"){
                        $("#page5Active").prop('checked', true);
                        $("#page5Title").attr("value", localStorage.getItem('page5title'));
                    }

                    if(localStorage.getItem('mediadetailsactive') === "yesmedia"){
                        $("#dmpmedia").attr("style", "display:block;");
                        $("#dmpmediawebsitepagename").attr("value", localStorage.getItem('pageDMPtitle'));
                        $("#dmpmediawebsiteurl").attr("value", localStorage.getItem('pageDMPiframe'));
                        $("#displayad1image").attr("value", localStorage.getItem('displayad1imgfilename'));
                        $("#displayad2image").attr("value", localStorage.getItem('displayad2imgfilename'));
                        $("#displayad3image").attr("value", localStorage.getItem('displayad3imgfilename'));
                        $("#displayad4image").attr("value", localStorage.getItem('displayad4imgfilename'));
                        if(localStorage.getItem('displayad1localimg') === "true"){
                            $("#localDisplayAd1Image").prop('checked', true);
                        }
                        if(localStorage.getItem('displayad2localimg') === "true"){
                            $("#localDisplayAd2Image").prop('checked', true);
                        }
                        if(localStorage.getItem('displayad3localimg') === "true"){
                            $("#localDisplayAd3Image").prop('checked', true);
                        }
                        if(localStorage.getItem('displayad4localimg') === "true"){
                            $("#localDisplayAd4Image").prop('checked', true);
                        }
                    }
                }
                console.log(">>>>> Finished Loading Brand Profile from Local Storage!");
    }else{
        loadJSON();
    }
}
